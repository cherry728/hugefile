//
//  ZPLInstrumentsPluginController.h
//  Instruments
//
//  Created by Yigitcan Yurtsever on 22.10.2018.
//  Copyright © 2018 Zeplin, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZPLInstrumentsPluginController : NSObject

+ (void)runActionWithDictionary:(NSDictionary *)dictionary;

@end
