function onRunAction(context) {
  if (!isFrameworkLoaded()) {
        var contentsPath = context.scriptPath.stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
        var resourcesPath = contentsPath.stringByAppendingPathComponent("Resources");

        var result = Mocha.sharedRuntime().loadFrameworkWithName_inDirectory("Instruments", resourcesPath);
        if (!result) {
            var alert = NSAlert.alloc().init();
            alert.alertStyle = NSAlertStyleCritical;
            alert.messageText = "Loading framework for “Instruments” failed"
            alert.informativeText = "Try exporting again and if the issue continues, contact us at support@zeplin.io."

            alert.runModal();

            return;
        }
    }

    var actionDictionary = context["action"];
    ZPLInstrumentsPluginController.runActionWithDictionary(actionDictionary);
}

function isFrameworkLoaded() {
    return Boolean(NSClassFromString("ZPLInstrumentsPluginController"));
}
